export const consultas = [
	{
			nome: 'Gabriel Santos Santana',
			data: '01/01/2024',
			idade: '20 anos',
			horario: '10:30',
			cidCard: '123.456-78',
			sangue: 'A+',
			logradouro: 'Rua nova',
			numero: '0'
	},
	{
			nome: 'Maria da Silva',
			data: '02/01/2024',
			idade: '20 anos',
			horario: '14:00',
			cidCard: '987.654-32',
			sangue: 'O-',
			logradouro: 'Avenida Principal',
			numero: '100'
	},
	{
			nome: 'João Oliveira',
			data: '05/01/2024',
			idade: '20 anos',
			horario: '11:15',
			cidCard: '555.123-99',
			sangue: 'B+',
			logradouro: 'Praça das Flores',
			numero: '25'
	},
	{
			nome: 'Ana Souza',
			data: '10/01/2024',
			idade: '20 anos',
			horario: '09:45',
			cidCard: '777.888-11',
			sangue: 'AB-',
			logradouro: 'Rua das Palmeiras',
			numero: '75'
	},
	{
			nome: 'Pedro Fernandes',
			data: '15/01/2024',
			idade: '20 anos',
			horario: '16:30',
			cidCard: '444.222-33',
			sangue: 'A-',
			logradouro: 'Avenida Central',
			numero: '30'
	}
];
