import NavBar from "@/components/NavBar";

const Main: React.FC = () => {
  return <NavBar />;
};

export default Main;
