import NavBar from "@/components/NavBar";

const Prontuario: React.FC = () => {
  return (
    <div>
      <NavBar />
    </div>
  );
};

export default Prontuario;
